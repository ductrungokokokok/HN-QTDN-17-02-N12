{
    'name': 'Quản lý tài sản và phòng họp',
    'version': '1.0',
    'category': 'Operations',
    'summary': 'Quản lý tài sản dùng chung và điều phối lịch sử dụng phòng họp',
    'description': """
Đề tài 6: Quản lý tài sản + Phòng họp.

Tính năng chính:
- Quản lý tài sản dùng chung trong phòng họp.
- Quản lý phòng họp, sức chứa, vị trí và trạng thái.
- Đặt lịch sử dụng phòng họp gắn với nhân viên từ module nhân sự.
- Kiểm tra trùng lịch và tài sản/phòng bảo trì.
- AI nội bộ gợi ý điều phối phòng họp và cảnh báo rủi ro.
- Demo External API tạo lịch đặt phòng từ ứng dụng bên ngoài.
    """,
    'depends': ['base', 'nhan_su'],
    'data': [
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'data/demo_data.xml',
        'views/tai_san_views.xml',
        'views/phong_hop_views.xml',
        'views/lich_dat_phong_views.xml',
        'views/menu.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
