#!/usr/bin/env python3
"""
Demo nâng cao: ứng dụng bên ngoài tạo lịch đặt phòng họp bằng Odoo XML-RPC.

Cách chạy:
    ODOO_USERNAME='admin@example1.com' ODOO_PASSWORD='admin' \
    python3 addons/quan_ly_tai_san_phong_hop/scripts/external_api_demo.py

Dọn dữ liệu demo:
    ODOO_USERNAME='admin@example1.com' ODOO_PASSWORD='admin' \
    python3 addons/quan_ly_tai_san_phong_hop/scripts/external_api_demo.py --cleanup
"""

import argparse
import os
import xmlrpc.client
from datetime import datetime, timedelta


URL = os.getenv("ODOO_URL", "http://localhost:8069")
DB = os.getenv("ODOO_DB", "admin")
USERNAME = os.getenv("ODOO_USERNAME", "admin")
PASSWORD = os.getenv("ODOO_PASSWORD", "")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Demo External API cho đề tài 6: tài sản + phòng họp."
    )
    parser.add_argument(
        "--cleanup",
        action="store_true",
        help="Xóa lịch đặt phòng demo có mã bắt đầu bằng DPAPI.",
    )
    return parser.parse_args()


def execute(models, uid, model, method, *args, **kwargs):
    return models.execute_kw(DB, uid, PASSWORD, model, method, list(args), kwargs or {})


def main():
    args = parse_args()
    if not PASSWORD:
        raise SystemExit("Thiếu ODOO_PASSWORD.")

    common = xmlrpc.client.ServerProxy(f"{URL}/xmlrpc/2/common")
    uid = common.authenticate(DB, USERNAME, PASSWORD, {})
    if not uid:
        raise SystemExit("Không đăng nhập được. Kiểm tra database, user hoặc password.")

    models = xmlrpc.client.ServerProxy(f"{URL}/xmlrpc/2/object")

    if args.cleanup:
        booking_ids = execute(
            models,
            uid,
            "lich_dat_phong_hop",
            "search",
            [["ma_dat_phong", "=like", "DPAPI%"]],
        )
        if booking_ids:
            execute(models, uid, "lich_dat_phong_hop", "unlink", booking_ids)
        print(f"Đã xóa {len(booking_ids)} lịch đặt phòng demo DPAPI.")
        return

    employee_ids = execute(
        models,
        uid,
        "nhan_vien",
        "search",
        [["ma_dinh_danh", "=", "NVAPI001"]],
        limit=1,
    )
    if employee_ids:
        employee_id = employee_ids[0]
    else:
        employee_id = execute(
            models,
            uid,
            "nhan_vien",
            "create",
            [{
                "ma_dinh_danh": "NVAPI001",
                "email": "nhanvien.api@example.com",
                "so_dien_thoai": "0900000001",
                "que_quan": "Đà Nẵng",
            }],
        )
        if isinstance(employee_id, list):
            employee_id = employee_id[0]

    room_ids = execute(
        models,
        uid,
        "phong_hop",
        "search",
        [["trang_thai", "=", "san_sang"]],
        limit=1,
    )
    if not room_ids:
        room_ids = [execute(
            models,
            uid,
            "phong_hop",
            "create",
            [{
                "name": "Phòng họp API",
                "vi_tri": "Tầng 3 - Khu Demo",
                "suc_chua": 15,
                "trang_thai": "san_sang",
                "nhan_vien_quan_ly_id": employee_id,
            }],
        )]
        if isinstance(room_ids[0], list):
            room_ids = [room_ids[0][0]]

    start = datetime.now().replace(second=0, microsecond=0) + timedelta(days=1, hours=2)
    end = start + timedelta(hours=1)
    for _attempt in range(24):
        conflict_ids = execute(
            models,
            uid,
            "lich_dat_phong_hop",
            "search",
            [
                ["phong_hop_id", "=", room_ids[0]],
                ["trang_thai", "in", ["cho_duyet", "da_duyet"]],
                ["thoi_gian_bat_dau", "<", end.strftime("%Y-%m-%d %H:%M:%S")],
                ["thoi_gian_ket_thuc", ">", start.strftime("%Y-%m-%d %H:%M:%S")],
            ],
            limit=1,
        )
        if not conflict_ids:
            break
        start += timedelta(hours=1)
        end += timedelta(hours=1)
    else:
        raise SystemExit("Không tìm được khung giờ trống trong 24 giờ tiếp theo.")

    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")

    booking_id = execute(
        models,
        uid,
        "lich_dat_phong_hop",
        "create",
        [{
            "ma_dat_phong": "DPAPI%s" % timestamp,
            "name": "Họp demo tạo từ External API",
            "phong_hop_id": room_ids[0],
            "nhan_vien_dat_id": employee_id,
            "nhan_vien_phu_trach_id": employee_id,
            "thoi_gian_bat_dau": start.strftime("%Y-%m-%d %H:%M:%S"),
            "thoi_gian_ket_thuc": end.strftime("%Y-%m-%d %H:%M:%S"),
            "so_nguoi_tham_du": 8,
            "muc_dich": "Minh họa ứng dụng bên ngoài đặt phòng họp qua Odoo External API.",
            "trang_thai": "cho_duyet",
        }],
    )
    if isinstance(booking_id, list):
        booking_id = booking_id[0]

    bookings = execute(
        models,
        uid,
        "lich_dat_phong_hop",
        "search_read",
        [["ma_dat_phong", "=like", "DPAPI%"]],
        fields=[
            "ma_dat_phong",
            "name",
            "phong_hop_id",
            "thoi_gian_bat_dau",
            "thoi_gian_ket_thuc",
            "trang_thai",
        ],
        limit=5,
        order="id desc",
    )

    print(f"Đã tạo lịch đặt phòng ID: {booking_id}")
    print("Các lịch đặt phòng demo mới nhất:")
    for booking in bookings:
        room_name = booking["phong_hop_id"][1] if booking["phong_hop_id"] else ""
        print(
            "- {ma_dat_phong} | {name} | {room} | {start} -> {end} | {state}".format(
                ma_dat_phong=booking["ma_dat_phong"],
                name=booking["name"],
                room=room_name,
                start=booking["thoi_gian_bat_dau"],
                end=booking["thoi_gian_ket_thuc"],
                state=booking["trang_thai"],
            )
        )


if __name__ == "__main__":
    main()
