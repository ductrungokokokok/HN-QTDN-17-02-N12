from odoo import api, fields, models
from odoo.exceptions import ValidationError


class PhongHop(models.Model):
    _name = 'phong_hop'
    _description = 'Phòng họp'
    _order = 'ma_phong, name'

    name = fields.Char("Tên phòng họp", required=True)
    ma_phong = fields.Char("Mã phòng", copy=False, readonly=True, index=True)
    vi_tri = fields.Char("Vị trí")
    suc_chua = fields.Integer("Sức chứa", default=10, required=True)
    trang_thai = fields.Selection([
        ('san_sang', 'Sẵn sàng'),
        ('dang_su_dung', 'Đang sử dụng'),
        ('bao_tri', 'Bảo trì'),
        ('tam_ngung', 'Tạm ngừng'),
    ], string="Trạng thái", default='san_sang', required=True)
    nhan_vien_quan_ly_id = fields.Many2one(
        'nhan_vien',
        string="Nhân viên quản lý",
    )
    tai_san_ids = fields.One2many(
        'tai_san_phong_hop',
        'phong_hop_id',
        string="Tài sản trong phòng",
    )
    lich_dat_ids = fields.One2many(
        'lich_dat_phong_hop',
        'phong_hop_id',
        string="Lịch đặt phòng",
    )
    so_tai_san = fields.Integer("Số loại tài sản", compute='_compute_counts')
    so_lich_dat = fields.Integer("Số lịch đặt", compute='_compute_counts')
    ghi_chu = fields.Text("Ghi chú")

    _sql_constraints = [
        ('ma_phong_unique', 'unique(ma_phong)', 'Mã phòng đã tồn tại.'),
        ('suc_chua_positive', 'check(suc_chua > 0)', 'Sức chứa phải lớn hơn 0.'),
    ]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('ma_phong'):
                vals['ma_phong'] = self.env['ir.sequence'].next_by_code(
                    'phong_hop'
                ) or 'PH00000'
        return super().create(vals_list)

    def _compute_counts(self):
        for record in self:
            record.so_tai_san = len(record.tai_san_ids)
            record.so_lich_dat = len(record.lich_dat_ids)

    @api.constrains('trang_thai')
    def _check_room_bookings_when_unavailable(self):
        for record in self:
            if record.trang_thai in ('bao_tri', 'tam_ngung'):
                active_bookings = record.lich_dat_ids.filtered(
                    lambda booking: booking.trang_thai in ('cho_duyet', 'da_duyet')
                )
                if active_bookings:
                    raise ValidationError(
                        "Không thể chuyển phòng sang bảo trì/tạm ngừng khi còn lịch chờ duyệt hoặc đã duyệt."
                    )
