from odoo import api, fields, models
from odoo.exceptions import ValidationError


class LichDatPhongHop(models.Model):
    _name = 'lich_dat_phong_hop'
    _description = 'Lịch đặt phòng họp'
    _order = 'thoi_gian_bat_dau desc'
    _rec_name = 'name'

    name = fields.Char("Tiêu đề cuộc họp", required=True)
    ma_dat_phong = fields.Char("Mã đặt phòng", copy=False, readonly=True, index=True)
    phong_hop_id = fields.Many2one(
        'phong_hop',
        string="Phòng họp",
        required=True,
        domain=[('trang_thai', '=', 'san_sang')],
    )
    nhan_vien_dat_id = fields.Many2one(
        'nhan_vien',
        string="Nhân viên đặt phòng",
        required=True,
    )
    nhan_vien_phu_trach_id = fields.Many2one(
        'nhan_vien',
        string="Người phụ trách cuộc họp",
    )
    thoi_gian_bat_dau = fields.Datetime("Thời gian bắt đầu", required=True)
    thoi_gian_ket_thuc = fields.Datetime("Thời gian kết thúc", required=True)
    so_nguoi_tham_du = fields.Integer("Số người tham dự", default=1, required=True)
    muc_dich = fields.Text("Mục đích cuộc họp")
    tai_san_yeu_cau_ids = fields.Many2many(
        'tai_san_phong_hop',
        string="Tài sản yêu cầu",
        domain=[('trang_thai', '=', 'san_sang')],
    )
    trang_thai = fields.Selection([
        ('nhap', 'Nháp'),
        ('cho_duyet', 'Chờ duyệt'),
        ('da_duyet', 'Đã duyệt'),
        ('hoan_thanh', 'Hoàn thành'),
        ('huy', 'Hủy'),
    ], string="Trạng thái", default='nhap', required=True)
    ai_phan_tich_luc = fields.Datetime("Thời điểm AI phân tích", readonly=True)
    ai_goi_y = fields.Text("AI gợi ý điều phối", readonly=True)
    ai_canh_bao = fields.Text("AI cảnh báo", readonly=True)
    ghi_chu = fields.Text("Ghi chú")

    _sql_constraints = [
        ('ma_dat_phong_unique', 'unique(ma_dat_phong)', 'Mã đặt phòng đã tồn tại.'),
        ('so_nguoi_positive', 'check(so_nguoi_tham_du > 0)', 'Số người tham dự phải lớn hơn 0.'),
    ]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('ma_dat_phong'):
                vals['ma_dat_phong'] = self.env['ir.sequence'].next_by_code(
                    'lich_dat_phong_hop'
                ) or 'DP00000'
        return super().create(vals_list)

    @api.constrains('phong_hop_id', 'thoi_gian_bat_dau', 'thoi_gian_ket_thuc', 'trang_thai')
    def _check_booking_time(self):
        for record in self:
            if record.thoi_gian_bat_dau and record.thoi_gian_ket_thuc:
                if record.thoi_gian_ket_thuc <= record.thoi_gian_bat_dau:
                    raise ValidationError("Thời gian kết thúc phải lớn hơn thời gian bắt đầu.")
            if not record.phong_hop_id or record.trang_thai in ('huy', 'hoan_thanh'):
                continue
            overlap_domain = [
                ('id', '!=', record.id),
                ('phong_hop_id', '=', record.phong_hop_id.id),
                ('trang_thai', 'in', ['cho_duyet', 'da_duyet']),
                ('thoi_gian_bat_dau', '<', record.thoi_gian_ket_thuc),
                ('thoi_gian_ket_thuc', '>', record.thoi_gian_bat_dau),
            ]
            if self.search_count(overlap_domain):
                raise ValidationError("Phòng họp đã có lịch trong khoảng thời gian này.")

    @api.onchange('phong_hop_id')
    def _onchange_phong_hop_id(self):
        if self.phong_hop_id and not self.nhan_vien_phu_trach_id:
            self.nhan_vien_phu_trach_id = self.phong_hop_id.nhan_vien_quan_ly_id

    def action_gui_duyet(self):
        self.write({'trang_thai': 'cho_duyet'})

    def action_duyet(self):
        for record in self:
            if record.phong_hop_id.trang_thai != 'san_sang':
                raise ValidationError("Chỉ có thể duyệt lịch cho phòng họp đang sẵn sàng.")
        self.write({'trang_thai': 'da_duyet'})

    def action_hoan_thanh(self):
        self.write({'trang_thai': 'hoan_thanh'})

    def action_huy(self):
        self.write({'trang_thai': 'huy'})

    def action_ai_goi_y_dieu_phoi(self):
        for record in self:
            warnings = []
            suggestions = []
            if record.phong_hop_id and record.so_nguoi_tham_du > record.phong_hop_id.suc_chua:
                warnings.append(
                    "Số người tham dự vượt sức chứa phòng %s/%s."
                    % (record.so_nguoi_tham_du, record.phong_hop_id.suc_chua)
                )
            if record.phong_hop_id and record.phong_hop_id.trang_thai != 'san_sang':
                warnings.append("Phòng họp hiện không ở trạng thái sẵn sàng.")
            unavailable_assets = record.tai_san_yeu_cau_ids.filtered(
                lambda asset: asset.trang_thai != 'san_sang'
            )
            if unavailable_assets:
                warnings.append(
                    "Một số tài sản chưa sẵn sàng: %s."
                    % ", ".join(unavailable_assets.mapped('name'))
                )
            if not record.tai_san_yeu_cau_ids:
                suggestions.append("Bổ sung tài sản yêu cầu như máy chiếu, màn hình hoặc micro nếu cuộc họp cần trình chiếu.")
            if record.phong_hop_id and record.so_nguoi_tham_du <= record.phong_hop_id.suc_chua:
                suggestions.append("Phòng họp hiện phù hợp với số lượng người tham dự.")
            if record.trang_thai == 'nhap':
                suggestions.append("Gửi duyệt lịch đặt phòng để quản lý xác nhận.")
            if warnings:
                suggestions.append("Kiểm tra lại phòng hoặc đổi sang phòng có sức chứa/tài sản phù hợp hơn.")

            record.ai_phan_tich_luc = fields.Datetime.now()
            record.ai_canh_bao = "\n".join(warnings) or "Chưa phát hiện rủi ro điều phối."
            record.ai_goi_y = "\n".join("- %s" % item for item in suggestions[:5])
