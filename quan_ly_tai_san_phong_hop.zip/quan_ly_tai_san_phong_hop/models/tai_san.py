from odoo import api, fields, models
from odoo.exceptions import ValidationError


class TaiSanPhongHop(models.Model):
    _name = 'tai_san_phong_hop'
    _description = 'Tài sản dùng chung cho phòng họp'
    _order = 'ma_tai_san, name'

    name = fields.Char("Tên tài sản", required=True)
    ma_tai_san = fields.Char("Mã tài sản", copy=False, readonly=True, index=True)
    loai_tai_san = fields.Selection([
        ('may_chieu', 'Máy chiếu'),
        ('man_hinh', 'Màn hình'),
        ('loa_mic', 'Loa/Micro'),
        ('ban_ghe', 'Bàn ghế'),
        ('dieu_hoa', 'Điều hòa'),
        ('khac', 'Khác'),
    ], string="Loại tài sản", default='khac', required=True)
    phong_hop_id = fields.Many2one(
        'phong_hop',
        string="Phòng đang bố trí",
        ondelete='set null',
    )
    so_luong = fields.Integer("Số lượng", default=1, required=True)
    ngay_mua = fields.Date("Ngày mua")
    gia_tri = fields.Float("Giá trị")
    trang_thai = fields.Selection([
        ('san_sang', 'Sẵn sàng'),
        ('dang_su_dung', 'Đang sử dụng'),
        ('bao_tri', 'Bảo trì'),
        ('hong', 'Hỏng'),
        ('thanh_ly', 'Thanh lý'),
    ], string="Trạng thái", default='san_sang', required=True)
    nhan_vien_phu_trach_id = fields.Many2one(
        'nhan_vien',
        string="Nhân viên phụ trách",
    )
    ghi_chu = fields.Text("Ghi chú")

    _sql_constraints = [
        ('ma_tai_san_unique', 'unique(ma_tai_san)', 'Mã tài sản đã tồn tại.'),
        ('so_luong_positive', 'check(so_luong > 0)', 'Số lượng tài sản phải lớn hơn 0.'),
        ('gia_tri_non_negative', 'check(gia_tri >= 0)', 'Giá trị tài sản không được âm.'),
    ]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('ma_tai_san'):
                vals['ma_tai_san'] = self.env['ir.sequence'].next_by_code(
                    'tai_san_phong_hop'
                ) or 'TS00000'
        return super().create(vals_list)

    @api.constrains('trang_thai', 'phong_hop_id')
    def _check_asset_room_status(self):
        for record in self:
            if record.phong_hop_id and record.trang_thai == 'thanh_ly':
                raise ValidationError("Tài sản đã thanh lý không được gắn vào phòng họp.")
