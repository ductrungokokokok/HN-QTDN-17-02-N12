# Đề tài 6: Quản lý tài sản + Phòng họp

## Mục tiêu nghiệp vụ

Module quản lý phòng họp như một tài sản dùng chung của đơn vị. Người dùng có thể khai báo phòng họp, gắn tài sản vào phòng, đặt lịch sử dụng, kiểm tra trùng lịch và theo dõi trạng thái phòng/tài sản.

## Các module kết hợp

- `nhan_su`: cung cấp dữ liệu nhân viên đặt phòng, nhân viên quản lý phòng và người phụ trách cuộc họp.
- `quan_ly_tai_san_phong_hop`: quản lý tài sản, phòng họp và lịch đặt phòng.

## Luồng demo đề xuất

1. Tạo nhân viên trong `QLNS / Quản lý nhân viên`.
2. Vào `QLNS / Đề tài 6 / Phòng họp`, tạo phòng họp và chọn nhân viên quản lý.
3. Vào `Tài sản phòng họp`, khai báo máy chiếu, micro, màn hình và gắn vào phòng.
4. Vào `Lịch đặt phòng`, tạo yêu cầu đặt phòng gắn với nhân viên.
5. Bấm `AI gợi ý` để hệ thống cảnh báo sức chứa, tài sản chưa sẵn sàng và đề xuất hành động.
6. Gửi duyệt và duyệt lịch đặt phòng.

## Điểm cải tiến

- Tài sản và phòng họp dùng chung dữ liệu, không nhập trùng.
- Lịch đặt phòng liên kết trực tiếp với phòng, tài sản và nhân viên từ module nhân sự.
- Có kiểm tra trùng lịch theo khoảng thời gian.
- Có trạng thái xử lý: nháp, chờ duyệt, đã duyệt, hoàn thành, hủy.
- Có AI nội bộ gợi ý điều phối phòng họp.
- Có External API để tạo lịch đặt phòng từ ứng dụng bên ngoài.

## Yêu cầu nâng cao đã thực hiện

### 1. AI điều phối phòng họp

Trong form `Lịch đặt phòng`, bấm nút `AI gợi ý`.

AI nội bộ sẽ:

- Cảnh báo nếu số người vượt sức chứa phòng.
- Cảnh báo nếu phòng hoặc tài sản chưa sẵn sàng.
- Gợi ý bổ sung tài sản cần thiết.
- Gợi ý gửi duyệt lịch hoặc đổi phòng phù hợp hơn.

### 2. External API

Chạy khi Odoo đang mở tại `http://localhost:8069`:

```bash
ODOO_USERNAME='admin@example1.com' ODOO_PASSWORD='admin' python3 addons/quan_ly_tai_san_phong_hop/scripts/external_api_demo.py
```

Dọn dữ liệu demo:

```bash
ODOO_USERNAME='admin@example1.com' ODOO_PASSWORD='admin' python3 addons/quan_ly_tai_san_phong_hop/scripts/external_api_demo.py --cleanup
```

Script sẽ tạo một lịch đặt phòng từ bên ngoài Odoo qua XML-RPC.

## Gợi ý business flow

Luồng chính: Nhân viên tạo yêu cầu đặt phòng -> hệ thống kiểm tra phòng/tài sản/trùng lịch -> AI gợi ý điều phối -> quản lý duyệt lịch -> nhân viên sử dụng phòng -> hoàn thành lịch.

Các actor nên đưa vào sơ đồ: Nhân viên, Quản lý phòng họp, Hệ thống Odoo, AI nội bộ, External API.

## Nguồn tham khảo

- Kho học phần FIT-DNU/Business-Internship.
- Tài liệu Odoo 15 về model, view, action, sequence và constraint.
- Tài liệu Odoo 15 External API.
